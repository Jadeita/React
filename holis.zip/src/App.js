import React from 'react'
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import {Nosotros} from "./components/Nosotros"
import {Productos} from "./components/Productos"
import {Inicio} from "./components/Inicio"
import {Regalo} from "./components/Regalo"
import { Navbar } from './components/Navbar'
import { Footer } from './components/Footer'



function App() {
  return (
    
    <Router >
      <br></br>
      <Navbar/>
      <br></br>
      <div >
        <Switch>
          <Route path= "/nosotros" component = {Nosotros}/>
          <Route path= "/regalo" component = {Regalo}/>
          <Route path= "/productos" component = {Productos}/>
          <Route path= "/" component = {Inicio}/>
        </Switch>
      </div>
      <Footer />
    </Router>
    
    
  );
}

export default App;
