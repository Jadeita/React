import React from 'react'


export const Inicio = () => (


  <div >
    <div>
    <img  style={{width:'100%'}} src="https://64.media.tumblr.com/7db32390afafa9f377c82647a2ff74e9/tumblr_pft7km267I1trxeuk_1280.png"></img>
    </div>
    
    <p style={{textAlign:'center'}}> <strong style={{fontSize: '70px'}}>BULLET JOURNAL SETS</strong>.</p>
    <div class="row">
    <div class="col-6">
      <div class="row">
      <div class="card mb-3">
        <h3 class="card-header">Cherry Blossom Set</h3>
        <div class="card-body">
        <h6 class="card-subtitle text-muted">Bullet Journal Set Cherry Colors</h6>
        </div>
        <img src="https://cdn.shopify.com/s/files/1/0011/6998/1487/products/StationeryPalBulletJournalSet-CherryBlossom1_1024x1024.jpg?v=1602603504"></img>
        <div class="card-body">
        <p class="card-text" style={{fontSize: '30px'}}>Bullet Journal set - Cherry Blossom $47 USD</p>
        </div>
      </div>
      </div>
    </div>

    <div class="col-6">
      <div class="row">
      <div class="card mb-3">
        <h3 class="card-header">Ocean Set</h3>
        <div class="card-body">
        <h6 class="card-subtitle text-muted">Bullet Journal Set Blue Colors</h6>
        </div>
        <img src="https://cdn.shopify.com/s/files/1/0011/6998/1487/products/StationeryPalBulletJournalSet-Ocean_1_1024x1024.jpg?v=1602603469"></img>
        <div class="card-body">
        <p class="card-text" style={{fontSize: '30px'}}>Bullet Journal set - Ocean $47 USD</p>
        </div>
      </div>
      </div>
    </div>


    <div class="col-6">
      <div class="row">
      <div class="card mb-3">
        <h3 class="card-header">Lavender Set</h3>
        <div class="card-body">
        <h6 class="card-subtitle text-muted">Bullet Journal Set Purple Colors</h6>
        </div>
        <img src="https://cdn.shopify.com/s/files/1/0011/6998/1487/products/StationeryPalBulletJournalSet-Lavender_3_1024x1024.jpg?v=1602603547"></img>
        <div class="card-body">
        <p class="card-text" style={{fontSize: '30px'}}>Bullet Journal set - Lavender $47 USD</p>
        </div>
      </div>
      </div>
    </div>
    <div class="col-6">
      <div class="row">
      <div class="card mb-3">
        <h3 class="card-header">Mint Set</h3>
        <div class="card-body">
        <h6 class="card-subtitle text-muted">Bullet Journal Set Green Colors</h6>
        </div>
        <img src="https://cdn.shopify.com/s/files/1/0011/6998/1487/products/StationeryPalBulletJournalSet-Mint1_1024x1024.jpg?v=1602603582"></img>
        <div class="card-body">
        <p class="card-text" style={{fontSize: '30px'}}>Bullet Journal set - Mint $47 USD</p>
        </div>
      </div>
      </div>
    </div>

    
  
  </div>


  </div>
  


  

)