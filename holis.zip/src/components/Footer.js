import React from 'react'

export const Footer = () => (
  
  <div className="jumbotron"  style={{backgroundColor:'#FFD7BA'}}>
    <h4 className="display-3"style={{textAlign:'center'}}>Contact Us</h4>
    <p>LOCATION.</p>
    <p className="lead"> 1600 Amphitheatre Parkway Mountain View, CA 94043, USA </p>
    <hr className="my-4" />
    <p>EMAIL.</p>
    <p className="lead">stationery@gmail.com</p>
  </div>
)