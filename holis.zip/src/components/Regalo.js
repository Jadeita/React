import React from 'react'

export const Regalo = () => (
  
    <div className="row">
    <div className="col-md-4">
          <div class="card mb-3">

              <img src="card.jpg"></img>
          </div>
    </div>
    <div className="col-md-4">
    <div class="form-group">
      <h3>Description</h3>
       <p  style={{fontSize: '25px'}}>Shopping for someone else but not sure what to give them?
       Give them the gift of choice with a Stationery Pal gift card.
       <br></br>
       <br></br>
       Gift cards are delivered by email and contain instructions to redeem them at checkout. 
       Our gift cards have no additional processing fees.</p>
    </div>
    </div>

    <div className="col-md-4">
    <div class="form-group">
      
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
      <label for="exampleSelect1">Gift Car Amount</label>
      <select class="form-control" id="exampleSelect1">
        <option>$50</option>
        <option>$100</option>
        <option>$150</option>
        <option>$200</option>
        <option>$300</option>
      </select>
      <label class="col-form-label col-form-label-sm" for="inputSmall">To</label>
        <input class="form-control form-control-sm" type="text" placeholder="Name" id="inputSmall"/>   
      
      <label for="exampleTextarea">Your message</label>
      <textarea class="form-control" id="exampleTextarea" rows="3">Write your message here</textarea>
      <button type="button" class="btn btn-success">buy</button>
    </div>
    </div>


    


    

  </div>
)