import React from 'react'

export const Nosotros = () => (
    <div>
        <h1 style={{textAlign:'center',fontSize:'100px'}}>About Us :)</h1>
        <p style={{fontSize:'30px'}}>We believed stationery is the least expensive luxury and it is one of the few things that bring us joy. 
            It has been a great pleasure serving all of our lovely customers. 
            Some of you might have contact with us before and some of you might not. We think it would be great if you get to know us better.</p>

            <div style={{textAlign:'center'}}> 
            <img src="https://www.imaginetricks.com/wp-content/uploads/2017/08/Cool-Girl-DP-in-ICE.jpg" className="img-thumbnail" alt="200px"  /> 
            <h1>CEO Lia Estrada</h1>
            <img src="https://d27yqp28rsqhzg.cloudfront.net/follower/54f2eaae-5c1a-45aa-b54e-c65217fb0456.jpg" className="img-thumbnail"  /> 
            <h1>Designer Jenny Estrada</h1>
            </div>

       
            


    </div>
)