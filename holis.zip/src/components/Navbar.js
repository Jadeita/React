import React from 'react'
import {Link} from 'react-router-dom'

export const Navbar = () => (
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
   
    <a class="navbar-brand" href="#" style={{fontSize: '30px'}} >Stationery</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarColor02">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
        <Link className="navbar-brand" to="/">Home</Link>
        </li>
        <li class="nav-item">
        <Link className="navbar-brand" to="/productos">Products</Link>
        </li>
        <li class="nav-item">
        <Link className="navbar-brand" to="/regalo">Gift Card</Link>

        </li>
        <li class="nav-item">
        <Link className="navbar-brand" to="/nosotros">About Us</Link>
        </li>
       
      </ul>
    </div>
  </nav>

      

     
)