import React from 'react'

export const Productos = () => (
    <div className="container-fluid">
        <br></br>
    <div className="row">
      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Water Colors Brush Pens</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Water Colors Brush Pens set of 20 colors</h6>
                </div>
                <img src="img1.webp"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Water Colors Brush Pens -  $50 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      </div>

      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Pure Color stick Notes</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Pure Color stick Notes set of 6 (red, pink, yellow or blue)</h6>
                </div>
                <img src="img4.jpg"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Pure Color stick Notes  - $20 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      </div>

      <div className="col-md-4">
        <div class="card mb-3">
            <h3 class="card-header">Plus Whiper Mr Correction Tape</h3>
            <div class="card-body">
            <h6 class="card-subtitle text-muted">Plus Whiper Mr Correction Tape (One piece) </h6>
            </div>
            <img src="img5.jpg"></img>
            <div class="card-body">
            <p class="card-text" style={{fontSize: '30px'}}> Mr Correction Tape -$3 USD</p>
            <button type="button" class="btn btn-success">buy</button>
            </div>
        </div>
      </div>
    </div>
    <div className="row">
      <div className="col-md-4">
        <div class="card mb-3">
            <h3 class="card-header">Polka Dots Sticker cold colors</h3>
            <div class="card-body">
            <h6 class="card-subtitle text-muted">Polka Dots Sticker for bullet journal cold colors</h6>
            </div>
            <img src="img6.webp"></img>
            <div class="card-body">
            <p class="card-text" style={{fontSize: '30px'}}>Polka Dots set (100pcs) - $47 USD</p>
            <button type="button" class="btn btn-success">buy</button>

            </div>
        </div>
      
      </div>
      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Pens Lavender Set</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Stabilo and pens from bullet journal lavender set </h6>
                </div>
                <img src="img8.jpg"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Pens lavender set - $30 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      
      </div>
      <div className="col-md-4">
        <div class="card mb-3">
            <h3 class="card-header">Random Patterns Washi Tape </h3>
            <div class="card-body">
            <h6 class="card-subtitle text-muted">WGrid Dot Twill Stripe Patterns Washi Tape (Set of 4)</h6>
            </div>
            <img src="img3.webp"></img>
            <div class="card-body">
            <p class="card-text" style={{fontSize: '30px'}}>Washi Tape Grid Dot - $10 USD</p>
            <button type="button" class="btn btn-success">buy</button>

            </div>
        </div>
      </div>
    </div>
    <div className="row">
      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Stabilo Boss Highlighter Pastel</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Stabilo Boss Pastel  set of 6</h6>
                </div>
                <img src="img2.jpg"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Stabilo Boss Original Pastel Colors - $10 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      </div>
      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Cherry Blossom Set</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Bullet Journal Set Cherry Colors</h6>
                </div>
                <img src="https://cdn.shopify.com/s/files/1/0011/6998/1487/products/StationeryPalBulletJournalSet-CherryBlossom1_1024x1024.jpg?v=1602603504"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Bullet Journal Cherry Blossom set -  $47 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      </div>
      <div className="col-md-4">
            <div class="card mb-3">
                <h3 class="card-header">Milkliner Highlighter Pen (Set of 12)</h3>
                <div class="card-body">
                <h6 class="card-subtitle text-muted">Milkliner  (Set of 12)</h6>
                </div>
                <img src="img7.webp"></img>
                <div class="card-body">
                <p class="card-text" style={{fontSize: '30px'}}>Milkliner Highlighter Pen (Set of 12) -  $35 USD</p>
                <button type="button" class="btn btn-success">buy</button>

                </div>
            </div>
      </div>
    </div>
  </div>

    
    
)